/*
  # Email verification system

  1. New Tables
    - `verification_requests`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null)
      - `verified` (boolean)
      - `expires_at` (timestamptz)
      - `created_at` (timestamptz)
      - `type` (text) - 'roi' or 'assessment'
    
  2. Security
    - Enable RLS on verification_requests table
    - Add policies for inserting and updating verification requests
*/

CREATE TABLE IF NOT EXISTS verification_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  verified boolean DEFAULT false,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  type text NOT NULL CHECK (type IN ('roi', 'assessment'))
);

ALTER TABLE verification_requests ENABLE ROW LEVEL SECURITY;

-- Allow inserting new verification requests
CREATE POLICY "Anyone can create verification requests"
  ON verification_requests
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow reading own verification requests
CREATE POLICY "Users can read their own verification requests"
  ON verification_requests
  FOR SELECT
  TO public
  USING (email = current_setting('request.jwt.claims')::json->>'email');

-- Allow updating own verification requests
CREATE POLICY "Users can update their own verification requests"
  ON verification_requests
  FOR UPDATE
  TO public
  USING (email = current_setting('request.jwt.claims')::json->>'email');