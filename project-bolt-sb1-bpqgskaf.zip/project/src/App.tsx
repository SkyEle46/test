import React, { useState } from 'react';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { BusinessDrivers } from './components/BusinessDrivers';
import { EngagementIndicators } from './components/EngagementIndicators';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Footer } from './components/Footer';
import { GrowthFramework } from './components/GrowthFramework';
import { CaseStudies } from './components/CaseStudies';
import { SuccessTimeline } from './components/SuccessTimeline';
import { ProfitAnalysis } from './components/ProfitAnalysis';
import { BusinessChecklist } from './components/BusinessChecklist';
import { FloatingCTA } from './components/FloatingCTA';
import { SocialProof } from './components/SocialProof';

// Import assessments directly
import { TimeAssessment } from './components/assessments/TimeAssessment';
import { TeamAssessment } from './components/assessments/TeamAssessment';
import { GrowthAssessment } from './components/assessments/GrowthAssessment';

function App() {
  const [currentAssessment, setCurrentAssessment] = useState<'time' | 'team' | 'growth' | null>(null);

  return (
    <div className="min-h-screen">
      <ErrorBoundary>
        <Hero onAssessmentStart={setCurrentAssessment} />
        <Services />
        <BusinessDrivers />
        <GrowthFramework />
        <CaseStudies />
        <SuccessTimeline />
        <ProfitAnalysis />
        <BusinessChecklist />
        <EngagementIndicators />
        <Footer />
        <FloatingCTA />
        <SocialProof />

        {currentAssessment === 'time' && <TimeAssessment />}
        {currentAssessment === 'team' && <TeamAssessment />}
        {currentAssessment === 'growth' && <GrowthAssessment />}
      </ErrorBoundary>
    </div>
  );
}

export default App;