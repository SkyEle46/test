import React, { useEffect, useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { trackEvent } from '../../lib/analytics';

interface Section {
  id: string;
  name: string;
  tracked: boolean;
}

export const ScrollDepthTracker = () => {
  const [sections] = useState<Section[]>([
    { id: 'hero', name: 'Hero Section', tracked: false },
    { id: 'services', name: 'Services Section', tracked: false },
    { id: 'business-drivers', name: 'Business Drivers', tracked: false },
    { id: 'growth-framework', name: 'Growth Framework', tracked: false },
    { id: 'case-studies', name: 'Case Studies', tracked: false },
    { id: 'contact', name: 'Contact Form', tracked: false }
  ]);

  const trackSection = (sectionId: string) => {
    const section = sections.find(s => s.id === sectionId);
    if (section && !section.tracked) {
      trackEvent({
        category: 'Scroll',
        action: 'Section View',
        label: section.name
      });
      section.tracked = true;
    }
  };

  sections.forEach(section => {
    const { ref } = useInView({
      threshold: 0.5,
      onChange: (inView) => {
        if (inView) {
          trackSection(section.id);
        }
      }
    });

    useEffect(() => {
      const element = document.getElementById(section.id);
      if (element) {
        // @ts-ignore
        ref(element);
      }
    }, [ref]);
  });

  return null;
};