import React, { useEffect } from 'react';

export const SessionRecorder = () => {
  useEffect(() => {
    const events: Array<{
      type: string;
      timestamp: number;
      data: any;
    }> = [];

    const recordEvent = (type: string, data: any) => {
      events.push({
        type,
        timestamp: Date.now(),
        data
      });

      // Store in localStorage, rotating if too large
      if (events.length > 1000) events.shift();
      localStorage.setItem('session_events', JSON.stringify(events));
    };

    const handlers = {
      click: (e: MouseEvent) => {
        const target = e.target as HTMLElement;
        recordEvent('click', {
          x: e.clientX,
          y: e.clientY,
          element: target.tagName,
          id: target.id,
          class: target.className
        });
      },
      
      scroll: () => {
        recordEvent('scroll', {
          y: window.scrollY,
          percent: (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
        });
      },
      
      input: (e: Event) => {
        const target = e.target as HTMLInputElement;
        recordEvent('input', {
          element: target.tagName,
          type: target.type,
          id: target.id
        });
      }
    };

    window.addEventListener('click', handlers.click);
    window.addEventListener('scroll', handlers.scroll);
    document.addEventListener('input', handlers.input);

    return () => {
      window.removeEventListener('click', handlers.click);
      window.removeEventListener('scroll', handlers.scroll);
      document.removeEventListener('input', handlers.input);
    };
  }, []);

  return null;
};