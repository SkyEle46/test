import React from 'react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    name: "Sarah Mitchell",
    business: "Manufacturing Solutions Inc.",
    quote: "I used to work 70-hour weeks, missing my kids' events. Now my team runs the day-to-day operations, and I haven't missed a family dinner in months.",
    result: "Reduced working hours by 60% while increasing revenue by 40%",
    archetype: "Caregiver", // Nurturing leader who wants to take care of team and family
    pain: "Sacrificing family time for business demands"
  },
  {
    name: "Michael Chen",
    business: "Tech Innovations Ltd",
    quote: "The hardest part was letting go, but once I trusted the process, everything changed. My team now handles challenges I used to tackle alone.",
    result: "Successfully opened 2 new locations without increasing personal workload",
    archetype: "Ruler", // Natural leader learning to delegate
    pain: "Control issues preventing scaling"
  },
  {
    name: "David Thompson",
    business: "Premier Services Group",
    quote: "I was the bottleneck in my own business. Learning to trust my team and implement proper systems gave me back my life.",
    result: "First 2-week vacation in 5 years while business grew 25%",
    archetype: "Hero", // Overcame personal limitations for greater good
    pain: "Being the bottleneck in own success"
  }
];

export const CaseStudies = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-[#1a365d] mb-6 font-display">
            Their Journey to Freedom
          </h2>
          <p className="text-xl text-gray-600">
            Business owners just like you who transformed their companies from owner-dependent to self-running
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-[#f7fafc] p-8 rounded-lg shadow-lg relative">
              <div className="absolute -top-3 right-8 bg-[#ed8936] text-white text-xs px-3 py-1 rounded-full">
                {testimonial.archetype}
              </div>
              <Quote className="w-10 h-10 text-[#ed8936] mb-6" />
              <p className="text-gray-700 mb-6 italic">"{testimonial.quote}"</p>
              <div className="border-t pt-6">
                <p className="font-semibold text-[#1a365d]">{testimonial.name}</p>
                <p className="text-gray-600 text-sm mb-4">{testimonial.business}</p>
                <div className="bg-green-50 text-green-700 p-3 rounded-lg text-sm">
                  {testimonial.result}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};