import React from 'react';
import { ChevronDown } from 'lucide-react';

interface HeroProps {
  onAssessmentStart: (type: 'time' | 'team' | 'growth') => void;
}

export const Hero = ({ onAssessmentStart }: HeroProps) => {
  return (
    <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1a365d] to-[#2d4a77]">
      <div className="container mx-auto px-6 text-center">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
          Transform Your Business
        </h1>
        <p className="text-xl text-gray-200 mb-12">
          Take control of your business and reclaim your time
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <button 
            onClick={() => onAssessmentStart('time')}
            className="bg-white/10 backdrop-blur-sm p-6 rounded-lg hover:bg-white/20 transition-all"
          >
            <h3 className="text-white font-semibold mb-2">Time Assessment</h3>
            <p className="text-gray-200">Discover how to free up your schedule</p>
          </button>
          
          <button 
            onClick={() => onAssessmentStart('team')}
            className="bg-white/10 backdrop-blur-sm p-6 rounded-lg hover:bg-white/20 transition-all"
          >
            <h3 className="text-white font-semibold mb-2">Team Assessment</h3>
            <p className="text-gray-200">Build a high-performing team</p>
          </button>
          
          <button 
            onClick={() => onAssessmentStart('growth')}
            className="bg-white/10 backdrop-blur-sm p-6 rounded-lg hover:bg-white/20 transition-all"
          >
            <h3 className="text-white font-semibold mb-2">Growth Assessment</h3>
            <p className="text-gray-200">Scale your business effectively</p>
          </button>
        </div>
      </div>
    </section>
  );
}