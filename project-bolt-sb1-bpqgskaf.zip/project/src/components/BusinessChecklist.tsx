import React, { useState } from 'react';
import { CheckSquare, Download, Mail, CheckCircle } from 'lucide-react';
import { stageChecklists } from '../lib/profitDrivers';
import { Stage } from '../components/GrowthFramework/types';

export const BusinessChecklist = () => {
  const [selectedStage, setSelectedStage] = useState<Stage['name']>('CREATION');
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const checklist = stageChecklists[selectedStage];

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-[#1a365d] mb-6 font-display">
            Your Business Freedom Checklist
          </h2>
          <p className="text-xl text-gray-600">
            Get your stage-specific action plan for business transformation
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center gap-4 mb-12">
            {Object.keys(stageChecklists).map((stage) => (
              <button
                key={stage}
                onClick={() => setSelectedStage(stage as Stage['name'])}
                className={`px-4 py-2 rounded-lg transition-all ${
                  selectedStage === stage
                    ? 'bg-[#1a365d] text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {stage}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8 mb-12">
            <h3 className="text-2xl font-bold text-[#1a365d] mb-2">
              {checklist.title}
            </h3>
            <p className="text-gray-600 mb-8">{checklist.description}</p>

            <div className="space-y-8">
              {checklist.items.map((section, index) => (
                <div key={index}>
                  <h4 className="font-semibold text-[#1a365d] mb-4">
                    {section.category}
                  </h4>
                  <div className="space-y-4">
                    {section.tasks.map((task, taskIndex) => (
                      <div
                        key={taskIndex}
                        className="flex items-start p-4 bg-gray-50 rounded-lg"
                      >
                        <CheckSquare className={`w-5 h-5 mr-3 mt-1 ${
                          task.priority === 'high' 
                            ? 'text-red-500' 
                            : task.priority === 'medium'
                            ? 'text-yellow-500'
                            : 'text-green-500'
                        }`} />
                        <div>
                          <p className="font-medium text-gray-800">{task.task}</p>
                          <p className="text-sm text-gray-600">{task.impact}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {!isSubmitted ? (
            <div className="max-w-md mx-auto text-center">
              <h3 className="text-2xl font-bold text-[#1a365d] mb-4">
                Get Your Complete Freedom Checklist
              </h3>
              <p className="text-gray-600 mb-6">
                Download the full checklist with detailed implementation guides
              </p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="relative">
                  <Mail className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your business email"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-[#ed8936] hover:bg-[#dd7926] text-white font-bold py-3 px-6 rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  <Download className="w-5 h-5" />
                  Download Full Checklist
                </button>
              </form>
            </div>
          ) : (
            <div className="max-w-md mx-auto text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-2xl font-bold text-[#1a365d] mb-2">
                Your Checklist is Ready!
              </h3>
              <p className="text-gray-600">
                Check your inbox for your complete business freedom checklist and implementation guide.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};