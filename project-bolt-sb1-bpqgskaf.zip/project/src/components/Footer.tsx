import React from 'react';

export const Footer = () => {
  return (
    <footer className="bg-[#1a365d] text-white py-16">
      <div className="container mx-auto px-6">
        <div className="text-center">
          <p>&copy; {new Date().getFullYear()} Business Transformation. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}