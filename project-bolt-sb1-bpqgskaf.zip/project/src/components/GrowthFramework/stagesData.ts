import { Stage, StageStory } from './types';

export const stageStories: StageStory[] = [
  {
    stage: 'CREATION',
    title: "Sarah's Artisanal Bakery: From Kitchen to Storefront",
    content: "Sarah, a perfectionist baker (Melancholic), transformed her passion into a business. Starting with detailed recipe documentation and meticulous planning (appealing to Phlegmatic types), she tested her creations at farmers' markets. Through energetic customer interactions (Sanguine appeal) and determined goal-setting (Choleric focus), she opened her first shop within 8 months. Key focus: product excellence and customer validation."
  },
  {
    stage: 'CHAOS',
    title: "TechFix Solutions: Growing Pains",
    content: "Mike's repair shop exploded in demand. A natural problem-solver (Choleric), he struggled with overwhelming customer requests. His friendly team (Sanguine) needed structure. Through methodical system creation (Melancholic) and patient team training (Phlegmatic), he implemented scheduling software and service standards. Focus shifted from reactive to proactive management."
  },
  {
    stage: 'CONTROL',
    title: "GreenScape Landscaping: Systems Evolution",
    content: "David, a methodical planner (Phlegmatic), implemented KPIs and team scorecards. His energetic sales team (Sanguine) embraced performance tracking, while detail-oriented crews (Melancholic) appreciated clear standards. His decisive leadership (Choleric) balanced accountability with autonomy. Result: 40% efficiency increase through structured freedom."
  },
  {
    stage: 'PROSPERITY',
    title: "Elite Fitness Studio: Optimization Phase",
    content: "Jennifer's studio mastered operations. Her analytical approach (Melancholic) to trainer performance data, combined with motivational leadership (Sanguine), created a self-improving system. Patient mentoring (Phlegmatic) and strategic expansion (Choleric) led to three locations running seamlessly. Focus: enhancing already successful systems."
  },
  {
    stage: 'FREEDOM',
    title: "Global Logistics Inc: True Business Freedom",
    content: "Marcus built a self-running logistics empire. His strategic vision (Choleric) and systematic approach (Melancholic) created robust leadership development. Encouraging team creativity (Sanguine) while maintaining stable operations (Phlegmatic) resulted in a business that thrives without his daily presence. Now works just 10 hours weekly on strategic growth."
  }
];

export const stages: Stage[] = [
  // ... (keep existing stages data)
];