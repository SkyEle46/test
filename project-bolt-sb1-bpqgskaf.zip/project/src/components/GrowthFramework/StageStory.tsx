import React, { useState, useRef, useEffect } from 'react';
import { Stage } from './types';

interface StageStoryProps {
  stage: Stage;
  story: {
    title: string;
    content: string;
  };
}

export const StageStory = ({ stage, story }: StageStoryProps) => {
  const [showStory, setShowStory] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout>();

  const handleMouseEnter = () => {
    timeoutRef.current = setTimeout(() => {
      setShowStory(true);
    }, 5000); // 5 seconds hover
  };

  const handleMouseLeave = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    setShowStory(false);
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return (
    <div 
      className="relative"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {showStory && (
        <div className="absolute z-50 w-96 bg-white rounded-lg shadow-xl p-6 transform -translate-x-1/2 left-1/2 -top-4 animate-fadeIn">
          <div className={`${stage.color} w-2 absolute left-0 top-0 bottom-0 rounded-l-lg`} />
          <h4 className="text-lg font-bold text-[#1a365d] mb-3">{story.title}</h4>
          <p className="text-gray-600 text-sm leading-relaxed">{story.content}</p>
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 rotate-45 w-4 h-4 bg-white border-r border-b border-gray-200"></div>
        </div>
      )}
    </div>
  );
};