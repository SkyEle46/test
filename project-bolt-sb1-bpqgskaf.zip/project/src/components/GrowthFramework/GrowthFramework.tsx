import React, { useState } from 'react';
import { StageCard } from './StageCard';
import { stages } from './stagesData';
import { Calendar } from 'lucide-react';

export const GrowthFramework = () => {
  const [showScheduler, setShowScheduler] = useState(false);

  const handleScheduleAssessment = () => {
    const contactSection = document.querySelector('#contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-[#1a365d] mb-6 font-display">
            Transform Your Business Journey
          </h2>
          <p className="text-xl text-gray-600 mb-12">
            Navigate from startup challenges to business freedom with our proven growth framework
          </p>
          
          {/* Growth Framework Image */}
          <div className="relative w-full max-w-4xl mx-auto mb-16">
            <img 
              src="https://images.unsplash.com/photo-1512758017271-d7b84c2113f1?auto=format&fit=crop&w=1200&h=300&q=80" 
              alt="Business Growth Framework Stages"
              className="w-full h-[300px] object-cover rounded-lg shadow-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#1a365d]/80 to-[#2d4a77]/80 rounded-lg">
              <div className="absolute inset-0 flex items-center justify-between px-12">
                {['CREATION', 'CHAOS', 'CONTROL', 'PROSPERITY', 'FREEDOM'].map((stage, index) => (
                  <div key={stage} className="text-center">
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mb-3 mx-auto shadow-lg">
                      <span className="text-[#1a365d] font-bold text-xl">{index + 1}</span>
                    </div>
                    <h3 className="text-white font-bold text-lg">{stage}</h3>
                  </div>
                ))}
              </div>
              <div className="absolute inset-x-16 top-1/2 h-0.5 bg-white/30" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 max-w-7xl mx-auto">
          {stages.map((stage) => (
            <StageCard key={stage.name} stage={stage} />
          ))}
        </div>

        <div className="mt-16 text-center">
          <button 
            onClick={handleScheduleAssessment}
            className="bg-[#1a365d] hover:bg-[#2d4a77] text-white font-bold py-4 px-8 rounded-lg transition-all transform hover:scale-105 flex items-center justify-center gap-2 mx-auto group"
          >
            <Calendar className="w-5 h-5 group-hover:animate-bounce" />
            <span className="group-hover:hidden">Schedule Your Growth Assessment</span>
            <span className="hidden group-hover:inline">Book Your Strategy Session →</span>
          </button>
        </div>
      </div>
    </section>
  );
};