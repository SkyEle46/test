export interface Stage {
  number: number;
  name: string;
  color: string;
  textColor: string;
  items: string[];
  description: string;
}

export interface StageAction {
  title: string;
  description: string;
  impact: string;
}

export interface StageStory {
  stage: string;
  title: string;
  content: string;
}