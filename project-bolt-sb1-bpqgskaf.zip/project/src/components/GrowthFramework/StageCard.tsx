import React from 'react';
import { Stage } from './types';
import { StageStory } from './StageStory';
import { stageStories } from './stagesData';

interface StageCardProps {
  stage: Stage;
}

export const StageCard = ({ stage }: StageCardProps) => {
  const stageStory = stageStories.find(story => story.stage === stage.name);

  return (
    <div className="flex flex-col transform transition-all duration-300 hover:scale-105">
      <div className={`${stage.color} text-white p-6 rounded-t-lg shadow-lg`}>
        <div className="text-3xl font-bold mb-2">{stage.number}</div>
        <div className="text-xl font-semibold">{stage.name}</div>
      </div>
      <div className="bg-white p-6 rounded-b-lg shadow-lg flex-grow border-t-4 border-opacity-20 border-white">
        <p className="text-gray-600 mb-4">{stage.description}</p>
        <ul className="space-y-3">
          {stage.items.map((item) => (
            <li key={item} className="flex items-start">
              <svg className={`w-5 h-5 ${stage.textColor} mr-2 mt-1 flex-shrink-0`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              <span className="text-gray-700 font-medium">{item}</span>
            </li>
          ))}
        </ul>
        {stageStory && <StageStory stage={stage} story={stageStory} />}
      </div>
    </div>
  );
};