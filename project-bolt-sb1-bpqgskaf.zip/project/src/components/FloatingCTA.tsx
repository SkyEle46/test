import React, { useState, useEffect } from 'react';
import { BookOpen, X, Mail, ArrowRight, Clock } from 'lucide-react';

export const FloatingCTA = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    // Show timer after 30 seconds
    const timer = setTimeout(() => {
      if (!hasInteracted) {
        setTimeLeft(900); // 15 minutes in seconds
      }
    }, 30000);

    return () => clearTimeout(timer);
  }, [hasInteracted]);

  useEffect(() => {
    if (timeLeft === null) return;

    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev === null || prev <= 0) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleOpen = () => {
    setIsOpen(true);
    setHasInteracted(true);
    setTimeLeft(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle email submission here
    console.log('Email submitted:', email);
    setIsSubmitted(true);
    // Reset after 3 seconds
    setTimeout(() => {
      setIsOpen(false);
      setIsSubmitted(false);
      setEmail('');
    }, 3000);
  };

  return (
    <>
      <button
        onClick={handleOpen}
        className="fixed bottom-8 right-8 z-50 bg-[#ed8936] hover:bg-[#dd7926] text-white p-4 rounded-full shadow-lg transition-all transform hover:scale-105 flex items-center gap-2 group"
      >
        <BookOpen className="w-6 h-6" />
        <span className="hidden md:inline whitespace-nowrap group-hover:translate-x-1 transition-transform">
          Free Profit Guide
        </span>
        {timeLeft !== null && (
          <div className="absolute -top-12 right-0 bg-red-500 text-white px-3 py-1 rounded-full text-sm flex items-center gap-2 whitespace-nowrap animate-pulse">
            <Clock className="w-4 h-4" />
            Expires in {formatTime(timeLeft)}
          </div>
        )}
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 relative">
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <X className="w-6 h-6" />
            </button>

            {!isSubmitted ? (
              <>
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-[#1a365d] mb-2">
                    Stop Profit Leaks Now
                  </h3>
                  <p className="text-gray-600">
                    Download our free guide: "6 Hidden Ways Business Owners Leak Profit (And How to Fix Them)"
                  </p>
                </div>

                <div className="bg-[#f7fafc] p-4 rounded-lg mb-6">
                  <h4 className="font-semibold text-[#1a365d] mb-2">Inside the Guide:</h4>
                  <ul className="space-y-2">
                    {[
                      "The 80/20 rule of profit optimization",
                      "Hidden operational inefficiencies",
                      "Team productivity secrets",
                      "Pricing strategy blind spots",
                      "Cash flow optimization techniques",
                      "System automation opportunities"
                    ].map((item, index) => (
                      <li key={index} className="flex items-center text-gray-700">
                        <ArrowRight className="w-4 h-4 text-[#ed8936] mr-2 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-gray-700 mb-2">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your business email"
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ed8936] focus:border-transparent"
                        required
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-[#ed8936] hover:bg-[#dd7926] text-white font-bold py-3 px-6 rounded-lg transition-all flex items-center justify-center gap-2"
                  >
                    <BookOpen className="w-5 h-5" />
                    Get Your Free Guide
                  </button>
                </form>
              </>
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-xl font-bold text-[#1a365d] mb-2">
                  Your Guide is On Its Way!
                </h3>
                <p className="text-gray-600">
                  Check your inbox for your profit optimization guide.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};