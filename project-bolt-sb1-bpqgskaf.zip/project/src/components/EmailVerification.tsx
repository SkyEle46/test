import React, { useState } from 'react';
import { Mail, Send, CheckCircle } from 'lucide-react';
import { createVerificationRequest, verifyCode } from '../lib/supabase';

interface EmailVerificationProps {
  type: 'roi' | 'assessment';
  email: string;
  onVerified: () => void;
  onCancel: () => void;
}

export const EmailVerification = ({ type, email, onVerified, onCancel }: EmailVerificationProps) => {
  const [verificationCode, setVerificationCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      const isValid = await verifyCode(email, verificationCode, type);
      if (isValid) {
        onVerified();
      } else {
        setError('Invalid or expired verification code');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResend = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      await createVerificationRequest(email, type);
      setError('A new verification code has been sent');
    } catch (err) {
      setError('Failed to send verification code');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="text-center mb-6">
        <Mail className="w-12 h-12 text-[#ed8936] mx-auto mb-4" />
        <h3 className="text-xl font-bold text-[#1a365d] mb-2">
          Verify Your Email
        </h3>
        <p className="text-gray-600">
          We've sent a verification code to {email}
        </p>
      </div>

      <div>
        <label className="block text-gray-700 mb-2">Verification Code</label>
        <input
          type="text"
          value={verificationCode}
          onChange={(e) => setVerificationCode(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-lg text-center text-2xl tracking-wide"
          placeholder="Enter 6-digit code"
          maxLength={6}
          required
          disabled={isSubmitting}
        />
      </div>

      {error && (
        <p className="text-red-500 text-sm text-center">{error}</p>
      )}

      <button
        type="submit"
        className="w-full bg-[#ed8936] hover:bg-[#dd7926] text-white font-bold py-4 px-8 rounded-lg transition-all flex items-center justify-center gap-2"
        disabled={isSubmitting}
      >
        <CheckCircle className="w-5 h-5" />
        {isSubmitting ? 'Verifying...' : 'Verify Email'}
      </button>

      <div className="text-center">
        <button
          type="button"
          onClick={handleResend}
          className="text-[#ed8936] hover:text-[#dd7926] text-sm"
          disabled={isSubmitting}
        >
          Resend verification code
        </button>
        <span className="mx-2 text-gray-300">|</span>
        <button
          type="button"
          onClick={onCancel}
          className="text-gray-500 hover:text-gray-700 text-sm"
          disabled={isSubmitting}
        >
          Cancel
        </button>
      </div>
    </form>
  );
};