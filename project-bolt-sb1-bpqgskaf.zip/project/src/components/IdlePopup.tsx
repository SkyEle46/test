import React, { useState, useEffect } from 'react';
import { X, AlertCircle } from 'lucide-react';

export const IdlePopup = () => {
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    let isShown = false;

    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !isShown) {
        setShowPopup(true);
        isShown = true;
      }
    };

    // Show after 30 seconds of inactivity
    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        if (!isShown) {
          setShowPopup(true);
          isShown = true;
        }
      }, 30000);
    };

    document.addEventListener('mousemove', resetTimer);
    document.addEventListener('mouseout', handleMouseLeave);
    resetTimer();

    return () => {
      document.removeEventListener('mousemove', resetTimer);
      document.removeEventListener('mouseout', handleMouseLeave);
      clearTimeout(timeoutId);
    };
  }, []);

  if (!showPopup) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative">
        <button
          onClick={() => setShowPopup(false)}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-6">
          <AlertCircle className="w-12 h-12 text-[#ed8936] mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-[#1a365d] mb-2">
            Wait! Don't Miss This Opportunity
          </h3>
          <p className="text-gray-600">
            Get your free Business Freedom Score™ and discover exactly what's holding your business back.
          </p>
        </div>

        <button
          onClick={() => {
            setShowPopup(false);
            const assessmentSection = document.querySelector('#services');
            if (assessmentSection) {
              assessmentSection.scrollIntoView({ behavior: 'smooth' });
            }
          }}
          className="w-full bg-[#ed8936] hover:bg-[#dd7926] text-white font-bold py-3 px-6 rounded-lg transition-all"
        >
          Get My Score Now
        </button>
      </div>
    </div>
  );
};