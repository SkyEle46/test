import React, { useState } from 'react';
import { TrendingUp, AlertCircle, Download, CheckCircle } from 'lucide-react';
import { silverBullets, ProfitDriver } from '../lib/profitDrivers';

export const ProfitAnalysis = () => {
  const [selectedDriver, setSelectedDriver] = useState<ProfitDriver | null>(null);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <section className="py-24 bg-[#f7fafc]">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-[#1a365d] mb-6 font-display">
            Profit Driver Analysis
          </h2>
          <p className="text-xl text-gray-600">
            Discover proven strategies that consistently drive business growth and profitability
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
          {silverBullets.map((driver) => (
            <div 
              key={driver.id}
              className="bg-white rounded-lg shadow-lg p-6 cursor-pointer transform transition-all hover:scale-105"
              onClick={() => setSelectedDriver(driver)}
            >
              <TrendingUp className="w-10 h-10 text-[#ed8936] mb-4" />
              <h3 className="text-xl font-bold text-[#1a365d] mb-3">{driver.name}</h3>
              <p className="text-gray-600 mb-4">{driver.description}</p>
              <div className="bg-green-50 text-green-700 p-3 rounded-lg">
                {driver.impact}
              </div>
            </div>
          ))}
        </div>

        {!isSubmitted ? (
          <div className="max-w-md mx-auto text-center">
            <h3 className="text-2xl font-bold text-[#1a365d] mb-4">
              Get Your Complete Profit Analysis
            </h3>
            <p className="text-gray-600 mb-6">
              Download your comprehensive profit driver analysis and implementation guide
            </p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your business email"
                className="w-full p-3 border border-gray-300 rounded-lg"
                required
              />
              <button
                type="submit"
                className="w-full bg-[#ed8936] hover:bg-[#dd7926] text-white font-bold py-3 px-6 rounded-lg transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-5 h-5" />
                Download Full Analysis
              </button>
            </form>
          </div>
        ) : (
          <div className="max-w-md mx-auto text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <h3 className="text-2xl font-bold text-[#1a365d] mb-2">
              Your Analysis is Ready!
            </h3>
            <p className="text-gray-600">
              Check your inbox for your complete profit driver analysis and implementation guide.
            </p>
          </div>
        )}
      </div>

      {selectedDriver && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative">
            <button
              onClick={() => setSelectedDriver(null)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <AlertCircle className="w-6 h-6" />
            </button>

            <div className="mb-6">
              <h3 className="text-2xl font-bold text-[#1a365d] mb-2">
                {selectedDriver.name}
              </h3>
              <p className="text-gray-600">{selectedDriver.description}</p>
            </div>

            <div className="space-y-6">
              <div>
                <h4 className="font-semibold text-[#1a365d] mb-3">Warning Signs</h4>
                <ul className="space-y-2">
                  {selectedDriver.symptoms.map((symptom, index) => (
                    <li key={index} className="flex items-center text-gray-700">
                      <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                      {symptom}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-[#1a365d] mb-3">Solutions</h4>
                <ul className="space-y-2">
                  {selectedDriver.solutions.map((solution, index) => (
                    <li key={index} className="flex items-center text-gray-700">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                      {solution}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-[#1a365d] mb-3">Key Metrics</h4>
                <ul className="space-y-2">
                  {selectedDriver.metrics.map((metric, index) => (
                    <li key={index} className="flex items-center text-gray-700">
                      <TrendingUp className="w-5 h-5 text-[#ed8936] mr-2" />
                      {metric}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};