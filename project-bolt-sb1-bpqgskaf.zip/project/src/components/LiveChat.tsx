// Add to LiveChat component:
const personalityTypes = {
  analytical: ['metrics', 'data', 'process', 'system'],
  driver: ['results', 'quick', 'control', 'power'],
  amiable: ['team', 'support', 'help', 'care'],
  expressive: ['innovative', 'exciting', 'creative', 'transform']
};

const detectPersonality = (messages) => {
  // Analyze message content against personality keywords
  const wordCount = messages.reduce((acc, msg) => {
    const words = msg.text.toLowerCase().split(' ');
    personalityTypes.forEach((type, keywords) => {
      keywords.forEach(keyword => {
        if (words.includes(keyword)) acc[type] = (acc[type] || 0) + 1;
      });
    });
    return acc;
  }, {});
  
  return Object.entries(wordCount).sort((a,b) => b[1] - a[1])[0]?.[0] || 'analytical';
};

// Modify response generation based on personality type