import React from 'react';
import { Users, Target, Puzzle, Brain } from 'lucide-react';

const assessmentAreas = [
  {
    icon: Target,
    title: "Role Alignment",
    description: "Are your team members in positions that maximize their strengths?",
    questions: [
      "Do they consistently meet or exceed expectations?",
      "Are they energized by their daily tasks?",
      "Do their natural abilities match their responsibilities?"
    ]
  },
  {
    icon: Puzzle,
    title: "Team Dynamics",
    description: "How well do your team members work together to achieve results?",
    questions: [
      "Is there clear communication between team members?",
      "Do they collaborate effectively on projects?",
      "Are conflicts resolved constructively?"
    ]
  },
  {
    icon: Brain,
    title: "Behavioral Patterns",
    description: "Are your team's behaviors aligned with your business goals?",
    questions: [
      "Do they show initiative in problem-solving?",
      "Are they proactive in identifying opportunities?",
      "Do they take ownership of their responsibilities?"
    ]
  }
];

export const TeamAssessment = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-[#1a365d] mb-6 font-display">
            Is Your Team Positioned for Success?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            The right people in the wrong roles can hold your business back. Let's ensure your team is set up to thrive.
          </p>
          <div className="flex items-center justify-center gap-2 text-[#ed8936]">
            <Users className="w-6 h-6" />
            <span className="text-lg font-semibold">Join 250+ businesses that unlocked their team's full potential</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {assessmentAreas.map((area, index) => (
            <div key={index} className="bg-[#f7fafc] p-8 rounded-lg shadow-lg hover:shadow-xl transition-all">
              <area.icon className="w-12 h-12 text-[#ed8936] mb-6" />
              <h3 className="text-2xl font-bold text-[#1a365d] mb-4">{area.title}</h3>
              <p className="text-gray-600 mb-6">{area.description}</p>
              <div className="space-y-4">
                {area.questions.map((question, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-[#ed8936] rounded-full mt-2"></div>
                    <p className="text-gray-700">{question}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button className="bg-[#1a365d] hover:bg-[#2d4a77] text-white font-bold py-4 px-8 rounded-lg transition-all transform hover:scale-105">
            Get Your Free Team Assessment
          </button>
        </div>
      </div>
    </section>
  );
};