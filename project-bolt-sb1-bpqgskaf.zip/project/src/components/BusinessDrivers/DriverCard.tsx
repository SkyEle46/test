import React from 'react';
import { Driver } from './types';
import { Activity, CheckCircle } from 'lucide-react';

interface DriverCardProps {
  driver: Driver;
}

export const DriverCard = ({ driver }: DriverCardProps) => (
  <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
    <h3 className="text-xl font-bold text-[#1a365d] mb-4 flex items-center">
      <Activity className="w-5 h-5 mr-2 text-[#ed8936]" />
      {driver.title}
    </h3>
    <p className="text-gray-600 mb-6">{driver.description}</p>
    
    <div className="space-y-6">
      <div>
        <h4 className="font-semibold text-[#1a365d] mb-3">Key Metrics to Track</h4>
        <ul className="space-y-2">
          {driver.metrics.map((metric, index) => (
            <li key={index} className="flex items-start text-gray-700">
              <CheckCircle className="w-5 h-5 mr-2 text-[#ed8936] flex-shrink-0" />
              <span>{metric}</span>
            </li>
          ))}
        </ul>
      </div>
      
      <div>
        <h4 className="font-semibold text-[#1a365d] mb-3">Action Items</h4>
        <ul className="space-y-2">
          {driver.actionItems.map((item, index) => (
            <li key={index} className="flex items-start text-gray-700">
              <CheckCircle className="w-5 h-5 mr-2 text-green-500 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  </div>
);