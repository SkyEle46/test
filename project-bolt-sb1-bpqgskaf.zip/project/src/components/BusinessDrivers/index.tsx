import React from 'react';
import { CategorySection } from './CategorySection';
import { driverCategories } from './driversData';

export const BusinessDrivers = () => {
  return (
    <section className="py-24 bg-[#f7fafc]">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-[#1a365d] mb-6 font-display">
            You're Not Alone in This Journey
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Like many of the 250+ business owners we've helped, you've built something valuable through dedication and sacrifice. But the weight of carrying it all shouldn't rest solely on your shoulders.
          </p>
          <p className="text-lg text-gray-700">
            We understand because we've been there - missing family dinners, working weekends, and feeling like the business depends entirely on you.
          </p>
        </div>

        <div className="space-y-16">
          {driverCategories.map((category, index) => (
            <CategorySection key={index} category={category} />
          ))}
        </div>
      </div>
    </section>
  );
};