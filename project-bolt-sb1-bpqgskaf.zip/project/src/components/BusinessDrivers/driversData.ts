import { DriverCategory } from './types';

export const driverCategories: DriverCategory[] = [
  {
    name: "The Real Cost of Being Irreplaceable",
    description: "When you're the heart of every operation, success comes at a personal price",
    drivers: [
      {
        title: "Time Deficit",
        description: "The constant struggle between business demands and personal life",
        metrics: [
          "Missed family events and commitments",
          "Hours spent on operational tasks",
          "Weekend work frequency",
          "Last proper vacation taken"
        ],
        actionItems: [
          "Identify critical tasks only you can do",
          "Map out delegation opportunities",
          "Build trust-based team systems",
          "Create clear accountability structures"
        ]
      },
      {
        title: "Growth Ceiling",
        description: "When your personal capacity limits business potential",
        metrics: [
          "Revenue plateaus despite longer hours",
          "Delayed strategic initiatives",
          "Backlog of important decisions",
          "Team dependency on your input"
        ],
        actionItems: [
          "Develop leadership within your team",
          "Implement decision-making frameworks",
          "Create scalable processes",
          "Build self-managing teams"
        ]
      }
    ]
  },
  {
    name: "Breaking Free from the Daily Grind",
    description: "Transform from overworked owner to strategic leader",
    drivers: [
      {
        title: "Team Empowerment",
        description: "Building a team that runs the business, not just works in it",
        metrics: [
          "Independent decision-making rate",
          "Problem resolution without owner",
          "Employee satisfaction scores",
          "Internal promotion readiness"
        ],
        actionItems: [
          "Create clear success metrics",
          "Develop team leadership skills",
          "Implement regular training",
          "Build accountability systems"
        ]
      },
      {
        title: "Systems Evolution",
        description: "Creating a business that works without your constant presence",
        metrics: [
          "Automated process percentage",
          "Documentation completeness",
          "Cross-training effectiveness",
          "Emergency response capability"
        ],
        actionItems: [
          "Document core processes",
          "Create training materials",
          "Implement quality controls",
          "Develop contingency plans"
        ]
      }
    ]
  },
  {
    name: "The Hidden Cost of Success",
    description: "What's your business really costing you?",
    drivers: [
      {
        title: "Life Balance Deficit",
        description: "The unseen toll of being always-on",
        metrics: [
          "Stress levels and health impacts",
          "Relationship strain indicators",
          "Personal time deficit",
          "Quality of life score"
        ],
        actionItems: [
          "Identify energy drains",
          "Create boundaries",
          "Implement delegation systems",
          "Design recovery routines"
        ]
      }
    ]
  }
];