import React from 'react';
import { DriverCategory } from './types';
import { DriverCard } from './DriverCard';

interface CategorySectionProps {
  category: DriverCategory;
}

export const CategorySection = ({ category }: CategorySectionProps) => (
  <div className="mb-12">
    <h2 className="text-3xl font-bold text-[#1a365d] mb-4 font-display">
      {category.name}
    </h2>
    <p className="text-xl text-gray-600 mb-8">{category.description}</p>
    
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {category.drivers.map((driver, index) => (
        <DriverCard key={index} driver={driver} />
      ))}
    </div>
  </div>
);