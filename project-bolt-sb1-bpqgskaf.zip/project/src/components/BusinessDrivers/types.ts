export interface Driver {
  title: string;
  description: string;
  metrics: string[];
  actionItems: string[];
}

export interface DriverCategory {
  name: string;
  description: string;
  drivers: Driver[];
}