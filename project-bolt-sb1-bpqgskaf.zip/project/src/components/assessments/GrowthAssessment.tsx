import React, { useState } from 'react';
import { TrendingUp, X } from 'lucide-react';

const questions = [
  {
    question: "What's your current monthly revenue growth rate compared to industry average?",
    options: [
      "Below industry by >50%",
      "Below industry by 20-50%",
      "At or near industry average",
      "Exceeding industry by >20%"
    ]
  },
  {
    question: "How many of your key performance indicators (KPIs) are you currently hitting?",
    options: [
      "Less than 25% of targets",
      "25-50% of targets",
      "50-75% of targets",
      "Over 75% of targets"
    ]
  }
];

export const GrowthAssessment = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleClose = () => {
    window.location.reload();
  };

  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 relative">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="p-8">
          <div className="flex items-center gap-4 mb-8">
            <TrendingUp className="w-8 h-8 text-[#ed8936]" />
            <h2 className="text-2xl font-bold text-[#1a365d]">Growth Potential Assessment</h2>
          </div>

          {!showResults ? (
            <>
              <h3 className="text-xl font-semibold mb-6">{questions[currentQuestion].question}</h3>
              <div className="space-y-4">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    className="w-full text-left p-4 rounded-lg border-2 border-gray-200 hover:border-[#ed8936] transition-colors"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </>
          ) : !isSubmitted ? (
            <div className="text-center">
              <h3 className="text-2xl font-bold text-[#1a365d] mb-4">Your Assessment is Ready!</h3>
              <p className="text-gray-600 mb-8">Enter your email to receive your results</p>
              <form onSubmit={handleSubmit} className="max-w-md mx-auto">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full p-3 border rounded-lg mb-4"
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-[#ed8936] text-white font-bold py-3 rounded-lg hover:bg-[#dd7926]"
                >
                  Get My Results
                </button>
              </form>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-bold text-[#1a365d] mb-2">Thank You!</h3>
              <p className="text-gray-600">
                Check your inbox for your personalized Growth Potential Report.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};