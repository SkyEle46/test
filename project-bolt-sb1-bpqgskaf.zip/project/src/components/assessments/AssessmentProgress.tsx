import React from 'react';
import { motion } from 'framer-motion';

interface ProgressProps {
  current: number;
  total: number;
}

export const AssessmentProgress = ({ current, total }: ProgressProps) => {
  const percentage = ((current + 1) / total) * 100;

  return (
    <div className="mb-8">
      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
        <motion.div 
          className="bg-[#ed8936] h-2 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
      <div className="flex justify-between mt-2 text-sm text-gray-600">
        <span>Question {current + 1} of {total}</span>
        <span>{Math.round(percentage)}% Complete</span>
      </div>
    </div>
  );
};