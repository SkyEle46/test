import React, { useState } from 'react';
import { Clock, X } from 'lucide-react';

const questions = [
  {
    question: "How many hours per week do you spend on tasks that should be handled by your team?",
    options: [
      "Over 30 hours - I'm doing everyone's job",
      "20-30 hours - I'm heavily involved",
      "10-20 hours - Getting better at delegating",
      "Under 10 hours - Team handles most tasks"
    ]
  },
  {
    question: "When was the last time you felt truly present with your family, without work interrupting?",
    options: [
      "I can't remember the last time",
      "More than 6 months ago",
      "Within the last month",
      "I regularly disconnect from work"
    ]
  }
];

export const TimeAssessment = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleClose = () => {
    window.location.reload();
  };

  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 relative">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="p-8">
          <div className="flex items-center gap-4 mb-8">
            <Clock className="w-8 h-8 text-[#ed8936]" />
            <h2 className="text-2xl font-bold text-[#1a365d]">Time Freedom Assessment</h2>
          </div>

          {!showResults ? (
            <>
              <h3 className="text-xl font-semibold mb-6">{questions[currentQuestion].question}</h3>
              <div className="space-y-4">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    className="w-full text-left p-4 rounded-lg border-2 border-gray-200 hover:border-[#ed8936] transition-colors"
                  >
                    {option}
                  </button>
                ))}
              </div>
            </>
          ) : !isSubmitted ? (
            <div className="text-center">
              <h3 className="text-2xl font-bold text-[#1a365d] mb-4">Your Assessment is Ready!</h3>
              <p className="text-gray-600 mb-8">Enter your email to receive your results</p>
              <form onSubmit={handleSubmit} className="max-w-md mx-auto">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full p-3 border rounded-lg mb-4"
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-[#ed8936] text-white font-bold py-3 rounded-lg hover:bg-[#dd7926]"
                >
                  Get My Results
                </button>
              </form>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-bold text-[#1a365d] mb-2">Thank You!</h3>
              <p className="text-gray-600">
                Check your inbox for your personalized Time Freedom Report.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};