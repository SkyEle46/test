import React, { useState, useEffect } from 'react';
import { UserCheck, Award, Clock, Users } from 'lucide-react';

// Cialdini's Principles in action
const notifications = [
  // Social Proof
  { 
    name: 'Michael R.', 
    location: 'Toronto', 
    action: 'started their assessment',
    icon: UserCheck
  },
  // Authority
  { 
    name: 'Sarah L.', 
    location: 'Vancouver', 
    action: 'was featured in Business Weekly',
    icon: Award
  },
  // Scarcity
  { 
    name: 'David K.', 
    location: 'Calgary', 
    action: 'secured one of our last strategy sessions this month',
    icon: Clock
  },
  // Social Proof + Authority
  { 
    name: 'Elite Business Group', 
    location: 'National', 
    action: 'recommended our framework to their members',
    icon: Users
  }
];

export const SocialProof = () => {
  const [currentNotification, setCurrentNotification] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const showNotification = () => {
      setIsVisible(true);
      setTimeout(() => {
        setIsVisible(false);
        setTimeout(() => {
          setCurrentNotification((prev) => (prev + 1) % notifications.length);
        }, 500);
      }, 4000);
    };

    const interval = setInterval(showNotification, 10000);
    return () => clearInterval(interval);
  }, []);

  if (!isVisible) return null;

  const notification = notifications[currentNotification];
  const Icon = notification.icon;

  return (
    <div className="fixed bottom-24 left-8 z-50 animate-fadeIn">
      <div className="bg-white rounded-lg shadow-lg p-4 flex items-center gap-3 max-w-xs">
        <div className="w-10 h-10 bg-[#ed8936]/10 rounded-full flex items-center justify-center flex-shrink-0">
          <Icon className="w-6 h-6 text-[#ed8936]" />
        </div>
        <div>
          <p className="text-sm text-gray-600">
            <span className="font-semibold text-[#1a365d]">{notification.name}</span>
            {' from '}
            <span className="font-medium">{notification.location}</span>
            {' just '}
            {notification.action}
          </p>
          <p className="text-xs text-gray-400">Just now</p>
        </div>
      </div>
    </div>
  );
};