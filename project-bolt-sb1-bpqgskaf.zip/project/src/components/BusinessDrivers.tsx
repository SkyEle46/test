import React from 'react';

export const BusinessDrivers = () => {
  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center text-[#1a365d] mb-8">
          Business Drivers
        </h2>
        <p className="text-center text-xl text-gray-600">
          Key factors that drive your business success
        </p>
      </div>
    </section>
  );
}