import React from 'react';
import { CheckCircle, Clock, Target, Users, TrendingUp, Award } from 'lucide-react';

const milestones = [
  {
    icon: CheckCircle,
    title: "Initial Assessment",
    duration: "Week 1-2",
    description: "Deep dive into your business operations and growth opportunities"
  },
  {
    icon: Target,
    title: "Strategy Development",
    duration: "Week 3-4",
    description: "Custom roadmap creation based on your unique challenges"
  },
  {
    icon: Users,
    title: "Team Alignment",
    duration: "Month 2",
    description: "Implementation of team optimization strategies"
  },
  {
    icon: TrendingUp,
    title: "Systems Integration",
    duration: "Month 3",
    description: "Automation and efficiency improvements"
  },
  {
    icon: Award,
    title: "Growth Acceleration",
    duration: "Month 4+",
    description: "Scaling and optimization of successful strategies"
  }
];

export const SuccessTimeline = () => {
  return (
    <section className="py-24 bg-[#f7fafc]">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-[#1a365d] mb-6 font-display">
            Your Path to Success
          </h2>
          <p className="text-xl text-gray-600">
            A clear roadmap to transform your business and achieve your goals
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {milestones.map((milestone, index) => (
            <div key={index} className="relative flex items-start mb-12 last:mb-0">
              {/* Timeline line */}
              {index !== milestones.length - 1 && (
                <div className="absolute left-6 top-10 bottom-0 w-0.5 bg-gray-200" />
              )}
              
              {/* Icon */}
              <div className="relative z-10">
                <div className="w-12 h-12 rounded-full bg-[#ed8936] flex items-center justify-center">
                  <milestone.icon className="w-6 h-6 text-white" />
                </div>
              </div>

              {/* Content */}
              <div className="ml-8 flex-grow">
                <div className="bg-white p-6 rounded-lg shadow-lg">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-[#1a365d]">{milestone.title}</h3>
                    <span className="text-[#ed8936] font-semibold">{milestone.duration}</span>
                  </div>
                  <p className="text-gray-600">{milestone.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};