interface AnalyticsEvent {
  category: string;
  action: string;
  label?: string;
  value?: number;
}

class Analytics {
  trackEvent(event: AnalyticsEvent) {
    // Simple event tracking that sends directly to Google Analytics if available
    if ((window as any).gtag) {
      (window as any).gtag('event', event.action, {
        event_category: event.category,
        event_label: event.label,
        value: event.value
      });
    }
  }
}

export const analytics = new Analytics();