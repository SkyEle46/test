export const humanNeeds = {
  certainty: {
    triggers: ['proven', 'guaranteed', 'systematic', 'proven framework', 'tested'],
    content: 'Our proven 5-stage framework has helped 250+ business owners'
  },
  uncertainty: {
    triggers: ['transform', 'breakthrough', 'discover', 'unlock', 'potential'],
    content: 'Unlock hidden growth opportunities in your business'
  },
  significance: {
    triggers: ['exclusive', 'elite', 'selected', 'limited', 'special'],
    content: 'Join an elite group of business owners who have broken free'
  },
  connection: {
    triggers: ['community', 'together', 'understand', 'support', 'help'],
    content: 'You\'re not alone in this journey'
  },
  growth: {
    triggers: ['learn', 'develop', 'master', 'improve', 'advance'],
    content: 'Continue growing while your business runs itself'
  },
  contribution: {
    triggers: ['impact', 'legacy', 'difference', 'help others', 'give'],
    content: 'Build a legacy that impacts your team, family, and community'
  }
};