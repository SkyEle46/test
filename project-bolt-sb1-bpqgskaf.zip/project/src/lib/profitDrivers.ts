import { Stage } from '../components/GrowthFramework/types';

export interface ProfitDriver {
  id: string;
  name: string;
  description: string;
  impact: string;
  symptoms: string[];
  solutions: string[];
  metrics: string[];
}

export const silverBullets: ProfitDriver[] = [
  {
    id: "lead-generation",
    name: "Lead Generation Optimization",
    description: "Systematically attract qualified prospects",
    impact: "25-40% increase in qualified leads",
    symptoms: [
      "Inconsistent lead flow",
      "High cost per acquisition",
      "Low quality leads"
    ],
    solutions: [
      "Multi-channel lead system",
      "Lead scoring automation",
      "Nurture sequence implementation"
    ],
    metrics: [
      "Cost per lead",
      "Lead quality score",
      "Conversion rate by channel"
    ]
  },
  {
    id: "conversion-rate",
    name: "Conversion Rate Enhancement",
    description: "Transform more prospects into customers",
    impact: "30-50% increase in conversion rates",
    symptoms: [
      "Long sales cycles",
      "Low proposal win rate",
      "Inconsistent pricing"
    ],
    solutions: [
      "Value-based pricing strategy",
      "Sales process automation",
      "Objection management system"
    ],
    metrics: [
      "Proposal to close ratio",
      "Average sales cycle length",
      "Profit margin per sale"
    ]
  },
  {
    id: "customer-value",
    name: "Customer Value Maximization",
    description: "Increase revenue per customer",
    impact: "40-60% increase in customer lifetime value",
    symptoms: [
      "Low repeat purchase rate",
      "Minimal upsells",
      "High customer churn"
    ],
    solutions: [
      "Value ladder implementation",
      "Loyalty program automation",
      "Proactive retention system"
    ],
    metrics: [
      "Average order value",
      "Customer lifetime value",
      "Retention rate"
    ]
  }
];

export const stageChecklists: Record<Stage['name'], {
  title: string;
  description: string;
  items: Array<{
    category: string;
    tasks: Array<{
      task: string;
      priority: 'high' | 'medium' | 'low';
      impact: string;
    }>;
  }>;
}> = {
  'CREATION': {
    title: "Business Foundation Checklist",
    description: "Essential steps to establish a solid business foundation",
    items: [
      {
        category: "Strategic Planning",
        tasks: [
          {
            task: "Define unique value proposition",
            priority: "high",
            impact: "Clear market positioning"
          },
          {
            task: "Create 90-day action plan",
            priority: "high",
            impact: "Focused execution"
          }
        ]
      },
      {
        category: "Financial Systems",
        tasks: [
          {
            task: "Set up profit tracking system",
            priority: "high",
            impact: "Financial clarity"
          },
          {
            task: "Create cash flow forecast",
            priority: "medium",
            impact: "Better decision making"
          }
        ]
      }
    ]
  },
  'CHAOS': {
    title: "Systems Development Checklist",
    description: "Transform chaos into structured growth",
    items: [
      {
        category: "Process Documentation",
        tasks: [
          {
            task: "Document core processes",
            priority: "high",
            impact: "Consistent delivery"
          },
          {
            task: "Create training materials",
            priority: "medium",
            impact: "Faster onboarding"
          }
        ]
      },
      {
        category: "Team Development",
        tasks: [
          {
            task: "Define roles and responsibilities",
            priority: "high",
            impact: "Clear accountability"
          },
          {
            task: "Implement performance metrics",
            priority: "medium",
            impact: "Measurable growth"
          }
        ]
      }
    ]
  },
  'CONTROL': {
    title: "Optimization Checklist",
    description: "Fine-tune systems for predictable performance",
    items: [
      {
        category: "Performance Tracking",
        tasks: [
          {
            task: "Implement KPI dashboard",
            priority: "high",
            impact: "Data-driven decisions"
          },
          {
            task: "Set up weekly reviews",
            priority: "medium",
            impact: "Proactive management"
          }
        ]
      }
    ]
  },
  'PROSPERITY': {
    title: "Scale Readiness Checklist",
    description: "Prepare for sustainable growth",
    items: [
      {
        category: "Growth Systems",
        tasks: [
          {
            task: "Create scaling playbook",
            priority: "high",
            impact: "Repeatable growth"
          },
          {
            task: "Build leadership pipeline",
            priority: "high",
            impact: "Sustainable expansion"
          }
        ]
      }
    ]
  },
  'FREEDOM': {
    title: "Freedom Achievement Checklist",
    description: "Build a self-running business",
    items: [
      {
        category: "Leadership Development",
        tasks: [
          {
            task: "Implement succession planning",
            priority: "high",
            impact: "Business continuity"
          },
          {
            task: "Create strategic dashboard",
            priority: "medium",
            impact: "Remote management"
          }
        ]
      }
    ]
  }
};