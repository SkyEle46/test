import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const generateVerificationCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

export const createVerificationRequest = async (email: string, type: 'roi' | 'assessment') => {
  const code = generateVerificationCode();
  const expiresAt = new Date();
  expiresAt.setMinutes(expiresAt.getMinutes() + 30); // Code expires in 30 minutes

  const { data, error } = await supabase
    .from('verification_requests')
    .insert([
      {
        email,
        code,
        expires_at: expiresAt.toISOString(),
        type
      }
    ])
    .select()
    .single();

  if (error) {
    throw error;
  }

  return { code, expiresAt };
};

export const verifyCode = async (email: string, code: string, type: 'roi' | 'assessment') => {
  const { data, error } = await supabase
    .from('verification_requests')
    .select()
    .eq('email', email)
    .eq('code', code)
    .eq('type', type)
    .eq('verified', false)
    .gte('expires_at', new Date().toISOString())
    .single();

  if (error || !data) {
    return false;
  }

  // Mark code as verified
  const { error: updateError } = await supabase
    .from('verification_requests')
    .update({ verified: true })
    .eq('id', data.id);

  if (updateError) {
    throw updateError;
  }

  return true;
};