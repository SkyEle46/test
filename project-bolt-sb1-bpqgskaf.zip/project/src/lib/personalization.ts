export type PersonaType = 'analytical' | 'driver' | 'amiable' | 'expressive';

interface PersonaContent {
  cta: string;
  benefits: string[];
  testimonial: string;
}

export const personaContent: Record<PersonaType, PersonaContent> = {
  analytical: {
    cta: "Get Your Data-Driven Growth Plan",
    benefits: [
      "ROI-focused methodology",
      "Systematic process implementation",
      "Measurable results tracking",
      "Evidence-based strategies"
    ],
    testimonial: "The systematic approach and clear metrics helped me grow by 40%"
  },
  driver: {
    cta: "Fast-Track Your Business Growth",
    benefits: [
      "Quick implementation",
      "Direct path to results",
      "Power moves for growth",
      "Strategic control systems"
    ],
    testimonial: "I achieved more in 90 days than the last 3 years combined"
  },
  amiable: {
    cta: "Transform Your Business Journey Together",
    benefits: [
      "Supportive guidance",
      "Team-focused approach",
      "Balanced growth",
      "Harmonious systems"
    ],
    testimonial: "The supportive approach helped my whole team grow together"
  },
  expressive: {
    cta: "Unlock Your Business Potential",
    benefits: [
      "Innovative strategies",
      "Creative solutions",
      "Exciting opportunities",
      "Transformative results"
    ],
    testimonial: "The innovative framework revolutionized my approach"
  }
};

export const detectPersona = (interactions: string[]): PersonaType => {
  const keywords = {
    analytical: ['data', 'numbers', 'process', 'system', 'analysis'],
    driver: ['results', 'fast', 'now', 'quick', 'direct'],
    amiable: ['team', 'help', 'support', 'together', 'care'],
    expressive: ['exciting', 'creative', 'innovative', 'transform', 'potential']
  };

  const scores = Object.entries(keywords).reduce((acc, [type, words]) => {
    const score = interactions.reduce((sum, interaction) => {
      return sum + words.filter(word => interaction.toLowerCase().includes(word)).length;
    }, 0);
    return { ...acc, [type]: score };
  }, {} as Record<string, number>);

  return Object.entries(scores)
    .sort(([,a], [,b]) => b - a)[0][0] as PersonaType;
};