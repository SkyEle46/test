import { PersonaType } from './personalization';
import { behaviorTracker } from './behaviorTracking';

interface ContentVariant {
  headline: string;
  description: string;
  cta: string;
  emphasis: 'social-proof' | 'scarcity' | 'authority' | 'reciprocity';
}

const contentVariants: Record<PersonaType, ContentVariant[]> = {
  analytical: [
    {
      headline: "Data-Driven Business Transformation",
      description: "Achieve 43% average efficiency improvement through systematic optimization",
      cta: "Get Your Custom Analysis",
      emphasis: 'authority'
    },
    // Add more variants...
  ],
  driver: [
    {
      headline: "Fast-Track Your Business Growth",
      description: "Join top 5% of business owners who achieved freedom in 90 days",
      cta: "Start Your Transformation",
      emphasis: 'scarcity'
    }
    // Add more variants...
  ],
  amiable: [
    {
      headline: "Build a Self-Running Team You Trust",
      description: "250+ business owners transformed their teams with our framework",
      cta: "Start Your Journey",
      emphasis: 'social-proof'
    }
    // Add more variants...
  ],
  expressive: [
    {
      headline: "Revolutionary Business Freedom System",
      description: "Unlock your business's hidden potential with our proven methodology",
      cta: "Discover Your Potential",
      emphasis: 'reciprocity'
    }
    // Add more variants...
  ]
};

export class ContentOptimizer {
  private persona: PersonaType = 'analytical';
  private variantPerformance: Record<string, { views: number; conversions: number }> = {};

  setPersona(persona: PersonaType) {
    this.persona = persona;
  }

  trackVariantView(variantId: string) {
    if (!this.variantPerformance[variantId]) {
      this.variantPerformance[variantId] = { views: 0, conversions: 0 };
    }
    this.variantPerformance[variantId].views++;
  }

  trackVariantConversion(variantId: string) {
    if (this.variantPerformance[variantId]) {
      this.variantPerformance[variantId].conversions++;
    }
  }

  getBestVariant(): ContentVariant {
    const variants = contentVariants[this.persona];
    const userInsights = behaviorTracker.generateInsights();
    
    // Use insights to select best variant
    const hasLowEngagement = userInsights.some(i => i.includes('Low content exploration'));
    const hasFormIssues = userInsights.some(i => i.includes('Multiple attempts'));
    
    if (hasLowEngagement) {
      return variants.find(v => v.emphasis === 'scarcity') || variants[0];
    }
    if (hasFormIssues) {
      return variants.find(v => v.emphasis === 'social-proof') || variants[0];
    }
    
    return variants[0];
  }
}

export const contentOptimizer = new ContentOptimizer();