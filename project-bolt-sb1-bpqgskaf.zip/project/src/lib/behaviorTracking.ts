import { trackEvent } from './analytics';

interface UserBehavior {
  pageTime: Record<string, number>;
  scrollDepth: number;
  clickMap: Array<{ x: number; y: number; element: string }>;
  formInteractions: Record<string, number>;
}

class BehaviorTracker {
  private behavior: UserBehavior = {
    pageTime: {},
    scrollDepth: 0,
    clickMap: [],
    formInteractions: {}
  };

  private startTime: number = Date.now();
  private currentSection: string = '';

  trackPageSection(section: string) {
    const now = Date.now();
    if (this.currentSection) {
      this.behavior.pageTime[this.currentSection] = 
        (this.behavior.pageTime[this.currentSection] || 0) + 
        (now - this.startTime);
    }
    this.currentSection = section;
    this.startTime = now;
  }

  trackClick(e: MouseEvent, elementId: string) {
    this.behavior.clickMap.push({
      x: e.clientX,
      y: e.clientY,
      element: elementId
    });
  }

  trackScroll(depth: number) {
    this.behavior.scrollDepth = Math.max(this.behavior.scrollDepth, depth);
  }

  trackFormInteraction(formId: string) {
    this.behavior.formInteractions[formId] = 
      (this.behavior.formInteractions[formId] || 0) + 1;
  }

  generateInsights(): string[] {
    const insights: string[] = [];
    
    // Analyze page time distribution
    const totalTime = Object.values(this.behavior.pageTime).reduce((a, b) => a + b, 0);
    Object.entries(this.behavior.pageTime).forEach(([section, time]) => {
      const percentage = (time / totalTime) * 100;
      if (percentage > 30) {
        insights.push(`High engagement in ${section}: ${Math.round(percentage)}% of time`);
      }
    });

    // Analyze scroll depth
    if (this.behavior.scrollDepth < 50) {
      insights.push('Low content exploration - consider improving above-fold content');
    }

    // Analyze form interactions
    Object.entries(this.behavior.formInteractions).forEach(([form, count]) => {
      if (count > 3) {
        insights.push(`Multiple attempts on ${form} - might need simplification`);
      }
    });

    return insights;
  }
}

export const behaviorTracker = new BehaviorTracker();