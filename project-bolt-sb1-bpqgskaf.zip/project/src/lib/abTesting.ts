import { useState, useEffect } from 'react';

type Variant = 'A' | 'B';

export const useABTest = (testName: string): Variant => {
  const [variant, setVariant] = useState<Variant>('A');

  useEffect(() => {
    // Consistent user experience
    const storedVariant = localStorage.getItem(`ab_${testName}`);
    if (storedVariant === 'A' || storedVariant === 'B') {
      setVariant(storedVariant);
    } else {
      const newVariant: Variant = Math.random() > 0.5 ? 'A' : 'B';
      localStorage.setItem(`ab_${testName}`, newVariant);
      setVariant(newVariant);
    }
  }, [testName]);

  return variant;
};

export const trackConversion = (testName: string, variant: Variant) => {
  // Track conversion in analytics
  console.log(`Conversion for ${testName} variant ${variant}`);
};